// import BottomNavigationBar from "../components/BottomNavigationBar";
import CreatePost from "../components/modals/CreatePost";

const Test = () => {
    return (
        <div className="h-screen flex flex-col bg-slate-300">
            <CreatePost />
        </div>
    );
}

export default Test;